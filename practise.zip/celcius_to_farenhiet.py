#celcius_to_farenhiet
a=float(input("Enter celcius temperature:"))
b=((a)*9/5)+32
print (b)
