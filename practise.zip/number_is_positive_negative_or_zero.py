#program_for_number_is_positive_negative_or_zero
num=int(input("Enter a number"))
if num>0:
    print("+ve")
elif num<0:
    print("-ve")
else:
    print("zero")