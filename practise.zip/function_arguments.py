def func(name):
    print("hi",name)
func("samee")
def func1(greeting):
    print("bye",greeting)
func1("samee")