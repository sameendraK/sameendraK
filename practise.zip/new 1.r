list = [1,2,3,4,5,6,7,8,9,10]
n = int(input("input number to print 'multiplication' table:  "))
for p in list:
    c = n*i
    print(c)
