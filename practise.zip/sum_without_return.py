#sum_without_return
def sum():
    a=3
    b=3
    c=a+b
print(sum())