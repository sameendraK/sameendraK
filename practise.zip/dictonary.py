a=int(input("Enter first number"))
b=int(input("Enter second number"))
c=a+b
print("The value is ",c)