#sum using user defined function
def add(num1,num2):
    sum=num1+num2
    return sum
a=3
b=5
print("The sum of two numbers is ",add(a,b))