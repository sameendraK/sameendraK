#factorial of a number
a=int(input("Enter the number"))
if (a==0):
    print ("1")
elif (a<0):
    print("factorial doesnot exist for negative values")
else:
    for i in range (a,0):
        a=a*i
print (a)