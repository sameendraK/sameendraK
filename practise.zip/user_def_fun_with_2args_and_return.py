#fn_with_return
def add(a,b):
    c=a+b
    return c;
a=int(input("a value"))
b=int(input("b value"))
print ("The sum is ",add(a,b))
