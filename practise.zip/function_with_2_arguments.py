def sum_nr(a,b):
    sum=a+b
    print("added value is",sum)
n1,n2=3,3
sum_nr(n1,n2)