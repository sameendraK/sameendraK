a=4
print (a)
def 