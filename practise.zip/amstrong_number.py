#amstrong_number
a=int(input("Enter value"))
c=0
d=a
if a<=0:
    print ("Enter +ve value")
elif d>0:
    b=d%10
    e=b**3
    c+=e
elif c==a:
    print ("ams")
    elif c!=a:
        print("no") 