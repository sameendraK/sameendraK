#multiplication table
a=int(input("Enter number"))
b=int(input("Enter range"))
for i in range (1,b):
	c=a*i
print (c)