#user_def_fun_with_2args_and_no_return
def addition(n1,n2):
    c=n1+n2
    print("sum is ",c)
a=int(input("Enter A"))
b=int(input("Enter B"))
addition(a,b)